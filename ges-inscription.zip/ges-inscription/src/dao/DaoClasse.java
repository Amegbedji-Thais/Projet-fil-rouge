/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Classe;
import java.util.ArrayList;

/**
 *
 * @author Utilisateur
 */
public class DaoClasse {
    public int insert(Classe classe){
        return 0;
    }
    public ArrayList<Classe> selectAll(){
        return null;
    }
    public int update(Classe classe){
        return 0;
    }
    public int delete(int id){
        return 0;
    }
    public ArrayList<Classe> selectClasseByProfesseur(int id){
        return null;
    }
}
